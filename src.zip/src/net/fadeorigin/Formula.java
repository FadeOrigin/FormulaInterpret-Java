package net.fadeorigin;

import java.io.*;
import java.util.*;
import java.util.regex.*;

/**  powered by fadeOrigin **/
public class Formula {

	private String formula;
	private HashMap<String,Float> variableCollection;
	private ArrayList<HashMap<String,Object>> operationCollection;

	public Formula(String formula_Parameter) throws IOException {
		this.formula=formula_Parameter;
        //
        //turn formula to data structure
		String operators="+\\-\\*/";
		String formulaInterpretRegex="(["+operators+"]{0,1})([^"+operators+"]+)";
		Pattern pattern=Pattern.compile(formulaInterpretRegex);
        this.operationCollection=this.convertToOperationList(pattern);
	}

	//
    //output as float
	public Float resultAsFloat(HashMap<String,String> variableCollection){
	    String resultString=doTheJob(variableCollection);
        return Float.parseFloat(resultString);
    }

    //
    //output as integer,ignore decimal part
    public int resultAsInteger(HashMap<String,String> variableCollection){
        String resultString=doTheJob(variableCollection);
        return Integer.parseInt(resultString.substring(0,resultString.indexOf(".")));
    }

    //
	//check the variables and output the result as string
    private String doTheJob(HashMap<String,String> variableCollection){
        this.variableCollection=new HashMap<String,Float>();
        //
        //check if the variables are integer or float
        Iterator iterator=variableCollection.entrySet().iterator();
        while(iterator.hasNext()){
            Map.Entry<String,String> entry=(Map.Entry<String,String>) iterator.next();
            String variableName=entry.getKey();
            String variableValue=entry.getValue();
            if(isNumber(variableValue)){
                this.variableCollection.put(variableName,Float.parseFloat(variableValue));
            }else{
                throw new ClassCastException();
            }
        }
        //
        //
        Float resultFloat=calculate(this.operationCollection);
        return String.valueOf(resultFloat);
    }

	//
    //parse variables into formula data structure and return a float
	private Float calculate(ArrayList<HashMap<String,Object>> operationCollection){
	    float returnValue=0f;
	    for(HashMap<String,Object> hashMapInstance:operationCollection){
            Object operator=hashMapInstance.get("operator");
            Object operand=hashMapInstance.get("operand");
            Float operandFloat=0f;
            if(operand instanceof String){
                String operandString=(String)operand;
                if(variableCollection.containsKey(operandString)){
                    operandFloat=variableCollection.get(operandString);
                }else{
                    operandFloat=Float.parseFloat(operandString);
                }
            }
            else if(operand instanceof ArrayList){
                operandFloat=calculate((ArrayList<HashMap<String,Object>>)operand);
            }else{
                throw new NullPointerException();
            }
            switch ((String)operator){
                case "+":
                    returnValue+=operandFloat;
                    break;
                case "-":
                    returnValue-=operandFloat;
                    break;
                case "*":
                    returnValue*=operandFloat;
                    break;
                case "/":
                    returnValue/=operandFloat;
                    break;
                default:
                    throw new NullPointerException();
            }
        }
        //System.out.println(operationCollection.size()+" "+returnValue);
        return returnValue;
    }

    private ArrayList<HashMap<String,Object>> convertToOperationList(Pattern pattern){
        Stack<ArrayList<HashMap<String,Object>>> operationListStack=new Stack<ArrayList<HashMap<String,Object>>>();   //store operation list
        operationListStack.push(new ArrayList<HashMap<String,Object>>());
        Stack<String> operatorStack=new Stack<String>();    //Whenever an element pushed to operationListStack,an operator pushed to this stack
        operatorStack.push("+");

        String currentOperationString="";
        boolean readyToCreateAnOperation=true;
        int loopInt_1=0;    //this variable indicate current position while looping
        while(loopInt_1<this.formula.length()){
            String currentCharacter=this.formula.substring(loopInt_1,loopInt_1+1);
            if(currentCharacter.equals("(")){
                if(currentOperationString.equals("")){
                    operatorStack.push("+");
                }else{
                    operatorStack.push(currentOperationString);
                    currentOperationString="";
                    readyToCreateAnOperation=true;
                }
                operationListStack.push(new ArrayList<HashMap<String,Object>>());
            }else if(currentCharacter.equals(")")){
                if(currentOperationString.equals("")==false){
                    //
                    //create an operation
                    operationListStack.peek().add(findOperatorAndOperand(currentOperationString,pattern));
                    currentOperationString="";
                    readyToCreateAnOperation=true;
                }
                ArrayList<HashMap<String,Object>> newlyFinishedOperationCollection=operationListStack.peek();
                String operator=operatorStack.peek();
                operationListStack.pop();
                operatorStack.pop();
                HashMap<String,Object> currentOperation=new HashMap<String,Object>();
                currentOperation.put("operator",operator);
                currentOperation.put("operand",newlyFinishedOperationCollection);
                operationListStack.peek().add(currentOperation);
            }else if(this.isOperator(currentCharacter)){
                if(currentOperationString.equals("")){
                    //
                    //this is the beginning of an operation
                    currentOperationString=currentCharacter;
                    readyToCreateAnOperation=false;
                }else{
                    //
                    //this is the end of an operation
                    operationListStack.peek().add(findOperatorAndOperand(currentOperationString,pattern));
                    //
                    //and another operation's beginning
                    currentOperationString=currentCharacter;
                }
            }else{
                //
                //variable or number
                if(readyToCreateAnOperation){
                    currentOperationString="+"+currentCharacter;
                    readyToCreateAnOperation=false;
                }else{
                    currentOperationString+=currentCharacter;
                }
                //
                //string end,create a operationMao
                if(loopInt_1==this.formula.length()-1){
                    operationListStack.peek().add(findOperatorAndOperand(currentOperationString,pattern));
                    currentOperationString="";
                }
            }
            loopInt_1++;
        }
        //
        //analyse operation priority
        ArrayList<HashMap<String,Object>> returnOperationCollection=operationListStack.peek();
        loopInt_1=1;
        if(returnOperationCollection.size()>1){
            while(loopInt_1<returnOperationCollection.size()){
                //
                //get operator and operand from this operation
                String thisOperator=(String) returnOperationCollection.get(loopInt_1).get("operator");
                Object thisOperand= returnOperationCollection.get(loopInt_1).get("operand");
                //
                //get operator and operand from last operation
                String lastOperator=(String) returnOperationCollection.get(loopInt_1-1).get("operator");
                Object lastOperand= returnOperationCollection.get(loopInt_1-1).get("operand");
                //
                if(thisOperator.equals(lastOperator)){
                    //
                    //Nothing to do
                }else{
                    if(operationLevel(thisOperator)<operationLevel(lastOperator)){
                        //
                        //This operation has priority over last operation
                        //
                        //Remove this operation and last operation from operation list
                        returnOperationCollection.remove(loopInt_1-1);
                        returnOperationCollection.remove(loopInt_1-1);
                        //
                        //Create a new nested operation and add to former position
                        HashMap<String,Object> lastOperationMap=new HashMap<String,Object>();
                        lastOperationMap.put("operator","+");
                        lastOperationMap.put("operand",lastOperand);
                        HashMap<String,Object> thisOperationMap=new HashMap<String,Object>();
                        thisOperationMap.put("operator",thisOperator);
                        thisOperationMap.put("operand",thisOperand);
                        ArrayList<HashMap<String,Object>> nestOperationList=new ArrayList<HashMap<String,Object>>();
                        nestOperationList.add(lastOperationMap);
                        nestOperationList.add(thisOperationMap);
                        HashMap<String,Object> nestOperation=new HashMap<String,Object>();
                        nestOperation.put("operator",lastOperator);
                        nestOperation.put("operand",nestOperationList);
                        returnOperationCollection.add(loopInt_1-1,nestOperation);
                        //
                        //adjust the position
                        loopInt_1--;
                    }
                }
                loopInt_1++;
            }
        }
        //printOperationList(returnOperationCollection);
        return returnOperationCollection;
    }

    //
    //Interpret a string,return operator and operand
    private HashMap<String,Object> findOperatorAndOperand(String operationString,Pattern pattern){
        HashMap<String,Object> returnMap=new HashMap<String,Object>();
        Matcher matcherInstance=pattern.matcher(operationString);
        if(matcherInstance.find()){
            String operator=matcherInstance.group(1);
            String operand=matcherInstance.group(2);
            returnMap.put("operator",operator);
            returnMap.put("operand",operand);
            return returnMap;
        }else{
            throw new NullPointerException();
        }
    }

    //
    //print the operation
    private void printOperation(HashMap<String,Object> hashMap,int level){
        Object operator=hashMap.get("operator");
        Object operand=hashMap.get("operand");
        if(operand instanceof String){
            for(int forInt_1=0;forInt_1<level-1;forInt_1++){
                System.out.print("    ");
            }
            System.out.println((String) operator+(String) operand);
        }
        else if(operand instanceof ArrayList){
            for(HashMap<String,Object> hashMapInstance:(ArrayList<HashMap<String,Object>>)operand){
                this.printOperation(hashMapInstance,level+1);
            }
        }else{
            System.out.println(operand.toString());
        }
    }

    //
    //print the formula data structure
    private void printOperationList(ArrayList<HashMap<String,Object>> operationCollection){
        for(HashMap<String,Object> hashMapInstance:operationCollection){
            printOperation(hashMapInstance,1);
        }
    }


    //
    //return priority level of a specific operator
    private int operationLevel(String operator){
        if(operator.equals("*") || operator.equals("/")) {
            return 2;
        }else if(operator.equals("+") || operator.equals("-")){
            return 3;
        }else{
            throw new ClassCastException();
        }
    }

    //
    //check if the string is an integer or a float
    private boolean isNumber(String string){
        Pattern numberCheckPattern=Pattern.compile("[+-]{0,1}[0-9]+\\.*[0-9]*");
        Matcher numberCheckMatcher=numberCheckPattern.matcher(string);
        if(numberCheckMatcher.matches()){
            return true;
        }else{
            return false;
        }
    }

    //
    //check if the string is an operator
    private boolean isOperator(String string){
        if(string.equals("+") || string.equals("-") || string.equals("*") || string.equals("/")){
            return true;
        }else{
            return false;
        }

    }
}
